"""Command line entry point.

  python -m dcc serve                 jalankan server (host/port dari .env, default 0.0.0.0:18085)
  python -m dcc check                 uji koneksi database dan migrasi skema
  python -m dcc import-kml <file>     impor aset KML/KMZ langsung dari baris perintah
  python -m dcc reset-password <user> setel ulang kata sandi akun (interaktif)
"""
from __future__ import annotations

import argparse
import getpass
import logging
import sys
from pathlib import Path


def main(argv=None):
    p = argparse.ArgumentParser(prog="python -m dcc", description="Disaster Information Center DCC")
    sub = p.add_subparsers(dest="cmd")
    sub.add_parser("serve")
    sub.add_parser("check")
    imp = sub.add_parser("import-kml")
    imp.add_argument("file")
    rp = sub.add_parser("reset-password")
    rp.add_argument("username")
    args = p.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")

    from .config import load_settings
    from .db import Database

    settings = load_settings()
    cmd = args.cmd or "serve"
    if cmd == "serve":
        from logging.handlers import RotatingFileHandler

        log_dir = settings.data_dir / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        fh = RotatingFileHandler(log_dir / "dcc.log", maxBytes=10 * 1024 * 1024, backupCount=5, encoding="utf-8")
        fh.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))
        logging.getLogger().addHandler(fh)
        import uvicorn

        from .app import create_app

        app = create_app(settings)
        # Satu worker: collector BMKG & antrean WA berjalan di proses ini.
        uvicorn.run(app, host=settings.host, port=settings.port, proxy_headers=settings.trust_proxy_headers,
                    log_level="info", access_log=False)
        return 0
    db = Database(settings.database_url)
    if cmd == "check":
        db.migrate()
        row = db.one("SELECT version() AS v, current_database() AS d, current_user AS u")
        print(f"OK  database={row['d']} user={row['u']}\n    {row['v']}")
        n = db.one("SELECT count(*) AS n FROM assets WHERE active")["n"]
        print(f"    aset aktif: {n}")
        return 0
    if cmd == "import-kml":
        from . import assets, kml_import

        db.migrate()
        path = Path(args.file)
        records, problems = kml_import.parse_assets(kml_import.open_kml_stream(path.name, path.read_bytes()))
        res = assets.publish_snapshot(db, records, "kml", path.name, "cli", problems)
        print(f"Snapshot #{res['snapshot_id']}: {res['total']} aset (baru {res['inserted']}, diperbarui {res['updated']}, "
              f"nonaktif {res['deactivated']}), catatan {len(problems)}")
        for k, v in sorted(res["by_kind"].items()):
            print(f"  {k:10s} {v}")
        return 0
    if cmd == "reset-password":
        from . import security

        pw = getpass.getpass("Kata sandi baru: ")
        n = db.run("UPDATE users SET password_hash=%s, must_change_password=true, active=true WHERE lower(username)=%s",
                   (security.hash_password(pw), args.username.lower()))
        print("Berhasil." if n else "Akun tidak ditemukan.")
        return 0 if n else 1
    p.print_help()
    return 1


if __name__ == "__main__":
    sys.exit(main())
