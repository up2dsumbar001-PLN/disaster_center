<#
  Disaster Information Center - instalasi di Windows (tanpa Docker)

  Yang dilakukan:
    1. Membuat virtualenv Python .venv dan memasang paket dari requirements.txt
    2. Membuat role "dcc_app" dan database "disaster_center" pada PostgreSQL yang sudah ada
       (instance yang sama dengan event downloader, database dan user TERPISAH)
    3. Menulis berkas .env (bila belum ada) dan menguji koneksi + membuat tabel
    4. Opsional: membuat aturan Windows Firewall port 18085 hanya untuk 10.17.119.0/24

  Jalankan dari PowerShell (Run as Administrator bila ingin sekalian membuat aturan firewall):
    powershell -ExecutionPolicy Bypass -File .\scripts\windows\setup.ps1
#>
param(
  [string]$PgHost = "127.0.0.1",
  [int]$PgPort = 5432,
  [string]$PgSuperUser = "postgres",
  [string]$DbName = "disaster_center",
  [string]$DbUser = "dcc_app",
  [int]$AppPort = 18085,
  [string]$AllowedNetwork = "10.17.119.0/24",
  [switch]$SkipDb,
  [switch]$SkipFirewall
)
$ErrorActionPreference = "Stop"
$Root = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
Set-Location $Root
function Step($t) { Write-Host ""; Write-Host "==> $t" -ForegroundColor Cyan }

# ------------------------------------------------------------------ Python
Step "Memeriksa Python"
$pyExe = $null; $pyArgs = @()
foreach ($cand in @(@("py", "-3"), @("python"), @("python3"))) {
  try {
    $a = @(); if ($cand.Length -gt 1) { $a = $cand[1..($cand.Length - 1)] }
    $v = & $cand[0] @a -c "import sys; print('%d.%d' % sys.version_info[:2])" 2>$null
    if ($LASTEXITCODE -eq 0 -and $v) { $pyExe = $cand[0]; $pyArgs = $a; $ver = "$v".Trim(); break }
  } catch { }
}
if (-not $pyExe) { throw "Python tidak ditemukan. Pasang Python 3.10+ dari python.org (centang 'Add to PATH')." }
Write-Host "Python $ver ($pyExe $pyArgs)"
if ([version]$ver -lt [version]"3.10") { throw "Butuh Python 3.10 atau lebih baru (terpasang $ver)." }

Step "Membuat virtualenv .venv dan memasang paket"
if (-not (Test-Path ".venv\Scripts\python.exe")) { & $pyExe @pyArgs -m venv .venv }
$venvPy = Join-Path $Root ".venv\Scripts\python.exe"
& $venvPy -m pip install --upgrade pip | Out-Null
& $venvPy -m pip install -r requirements.txt
if ($LASTEXITCODE -ne 0) { throw "pip install gagal. Bila memakai proxy kantor, set dulu: `$env:HTTPS_PROXY='http://proxy:port'" }

# ---------------------------------------------------------------- Database
$dbPassword = $null
if (-not $SkipDb) {
  Step "Mencari psql.exe"
  $psql = (Get-Command psql.exe -ErrorAction SilentlyContinue).Source
  if (-not $psql) {
    $psql = Get-ChildItem "C:\Program Files\PostgreSQL\*\bin\psql.exe" -ErrorAction SilentlyContinue |
      Sort-Object FullName -Descending | Select-Object -First 1 -ExpandProperty FullName
  }
  if (-not $psql) { throw "psql.exe tidak ditemukan. Tambahkan folder bin PostgreSQL ke PATH atau jalankan dengan -SkipDb." }
  Write-Host "psql: $psql"

  $sec = Read-Host "Kata sandi superuser PostgreSQL '$PgSuperUser'" -AsSecureString
  $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec)
  $env:PGPASSWORD = [Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr)
  [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)

  function Psql($sql, $db = "postgres") {
    $out = & $psql -h $PgHost -p $PgPort -U $PgSuperUser -d $db -v ON_ERROR_STOP=1 -tAc $sql
    if ($LASTEXITCODE -ne 0) { throw "Perintah SQL gagal: $sql" }
    return $out
  }

  Step "Membuat role $DbUser dan database $DbName"
  Write-Host (Psql "SELECT version()")
  $chars = [char[]]"ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789"
  $dbPassword = -join (1..24 | ForEach-Object { $chars | Get-Random })
  $exists = Psql "SELECT 1 FROM pg_roles WHERE rolname = '$DbUser'"
  if ($exists -eq "1") {
    Write-Host "Role $DbUser sudah ada; kata sandinya diperbarui."
    Psql "ALTER ROLE $DbUser WITH LOGIN PASSWORD '$dbPassword'" | Out-Null
  } else {
    Psql "CREATE ROLE $DbUser WITH LOGIN PASSWORD '$dbPassword' NOSUPERUSER NOCREATEDB NOCREATEROLE" | Out-Null
  }
  $dbExists = Psql "SELECT 1 FROM pg_database WHERE datname = '$DbName'"
  if ($dbExists -ne "1") {
    Psql "CREATE DATABASE $DbName OWNER $DbUser" | Out-Null
    Write-Host "Database $DbName dibuat."
  } else {
    Write-Host "Database $DbName sudah ada (data lama dipertahankan)."
    Psql "ALTER DATABASE $DbName OWNER TO $DbUser" | Out-Null
  }
  Psql "REVOKE CONNECT ON DATABASE $DbName FROM PUBLIC" | Out-Null
  Psql "GRANT CONNECT ON DATABASE $DbName TO $DbUser" | Out-Null
  Psql "GRANT ALL ON SCHEMA public TO $DbUser" $DbName | Out-Null
  $enc = Psql "SELECT pg_encoding_to_char(encoding) FROM pg_database WHERE datname = '$DbName'"
  if ($enc -ne "UTF8") { Write-Warning "Encoding database $DbName adalah $enc. Disarankan UTF8." }
  Remove-Item Env:\PGPASSWORD
}

# --------------------------------------------------------------------- .env
Step "Menulis konfigurasi .env"
$envFile = Join-Path $Root ".env"
$dsn = "host=$PgHost port=$PgPort dbname=$DbName user=$DbUser password=$dbPassword"
if (Test-Path $envFile) {
  $content = Get-Content $envFile -Raw
  if ($dbPassword) {
    $content = [regex]::Replace($content, "(?m)^DCC_DATABASE_URL=.*$", "DCC_DATABASE_URL=$dsn")
    Set-Content -Path $envFile -Value $content -Encoding UTF8
    Write-Host ".env sudah ada; DCC_DATABASE_URL diperbarui."
  } else { Write-Host ".env sudah ada; tidak diubah." }
} else {
  $content = Get-Content (Join-Path $Root ".env.example") -Raw
  $content = $content -replace "(?m)^DCC_PORT=.*$", "DCC_PORT=$AppPort"
  $content = $content -replace "(?m)^DCC_ALLOWED_NETWORKS=.*$", "DCC_ALLOWED_NETWORKS=$AllowedNetwork,127.0.0.1/32,::1/128"
  if ($dbPassword) { $content = [regex]::Replace($content, "(?m)^DCC_DATABASE_URL=.*$", "DCC_DATABASE_URL=$dsn") }
  $secret = -join ((1..32) | ForEach-Object { "{0:x2}" -f (Get-Random -Maximum 256) })
  $content = $content -replace "(?m)^DCC_SECRET_KEY=.*$", "DCC_SECRET_KEY=$secret"
  Set-Content -Path $envFile -Value $content -Encoding UTF8
  Write-Host ".env dibuat."
}
# Batasi akses berkas .env (berisi kata sandi DB) ke Administrators, SYSTEM dan pengguna saat ini.
try {
  & icacls $envFile /inheritance:r /grant:r "*S-1-5-32-544:F" "*S-1-5-18:F" "$($env:USERNAME):F" | Out-Null
} catch { Write-Warning "Tidak dapat mengatur izin .env: $_" }

Step "Menguji koneksi database dan membuat tabel"
& $venvPy -m dcc check
if ($LASTEXITCODE -ne 0) { throw "Uji koneksi gagal. Periksa DCC_DATABASE_URL di .env dan pg_hba.conf." }

# ---------------------------------------------------------------- Firewall
if (-not $SkipFirewall) {
  Step "Aturan Windows Firewall"
  $isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
  if ($isAdmin) {
    & (Join-Path $PSScriptRoot "firewall.ps1") -Port $AppPort -RemoteAddress $AllowedNetwork
  } else {
    Write-Warning "Bukan Administrator: lewati firewall. Jalankan nanti sebagai Administrator: .\scripts\windows\firewall.ps1"
  }
}

Write-Host ""
Write-Host "Selesai." -ForegroundColor Green
Write-Host "  Jalankan uji coba : .\scripts\windows\run.ps1"
Write-Host "  Pasang sebagai layanan otomatis: .\scripts\windows\install-service.ps1 (Administrator)"
Write-Host "  Impor aset       : Administrasi > Data aset > 'ASET JARINGAN SUMBAR.kml' > Impor"
Write-Host "  Akses            : http://<IP-PC-ini>:$AppPort  dari jaringan $AllowedNetwork"
Write-Host "  Kata sandi admin awal tertulis di data\ADMIN-AWAL.txt setelah server pertama kali dijalankan."
